/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package MPrincipal;
import Ventanas.Bien;
/**
 *
 * @author alejandro
 */
public class Grafica {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bien b=new Bien();
        b.setVisible(true);
    }
    
}
