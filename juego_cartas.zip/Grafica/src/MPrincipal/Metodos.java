/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MPrincipal;

import MeJu.Card;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author alejandro
 */
public class Metodos {
    public void Gam(){
    Card.genCard(Card.playerCards);
    Card.genCard(Card.cpuCards);
    }
    public String mosCd(Card ob){
        String s;
        switch (ob.tipo) {
            case "Rey":
                s="src\\Imagenes\\rey_d.png";
                break;
            case "Mago":
                s="src\\Imagenes\\mago_d.png";
                break;
            case "Caballero":
                s="src\\Imagenes\\caballero_d.png";
                break;
            case "Arquero":
                s="src\\Imagenes\\arquero_d.png";
                break;
            case "Soldado":
                s="src\\Imagenes\\soldado_d.png";
                break;
            default:
                s="src\\Imagenes\\campesino_d.png";
                break;
        }
        return s;
    }
    public String mostCd (Card ob){
         String s;
        switch (ob.tipo) {
            case "Rey":
                s="src\\Imagenes\\rey_d.png";
                break;
            case "Mago":
                s="src\\Imagenes\\mago_d.png";
                break;
            case "Caballero":
                s="src\\Imagenes\\caballero_d.png";
                break;
            case "Arquero":
                s="src\\Imagenes\\arquero_d.png";
                break;
            case "Soldado":
                s="src\\Imagenes\\soldado_d.png";
                break;
            default:
                s="src\\Imagenes\\campesino_d.png";
                break;
        }
        return s;
    }
    public String mostCj(Card ob){
        String s;
        switch (ob.tipo) {
            case "Rey":
                s="src\\Imagenes\\rey_j.png";
                break;
            case "Mago":
                s="src\\Imagenes\\mago_j.png";
                break;
            case "Caballero":
                s="src\\Imagenes\\caballero_j.png";
                break;
            case "Arquero":
                s="src\\Imagenes\\arquero_j.png";
                break;
            case "Soldado":
                s="src\\Imagenes\\soldado_j.png";
                break;
            default:
                s="src\\Imagenes\\campesino_j.png";
                break;
        }
        return s;
    }
    public void iconlbl(JLabel l, String sr){
    ImageIcon im=new ImageIcon(sr);
    Icon ic=new ImageIcon(
    im.getImage().getScaledInstance(l.getWidth(),l.getHeight(),Image.SCALE_DEFAULT)
    );
    l.setIcon(ic);
    l.repaint();
    }
}
