package Ventanas;
import MPrincipal.Metodos;
import MeJu.Card;
import MeJu.Game;
import static MeJu.Game.ju_1;
import static MeJu.Game.op_1;
import javax.swing.JLabel;
public class DeadEnd extends javax.swing.JFrame {
    Metodos met=new Metodos();
    Game gg=new Game();
    /**
     * Creates new form DeadEnd
     */
    public DeadEnd() {
        initComponents();
        this.setLocationRelativeTo(null);
        loadLabels();
        tipSe();
        jPanel2.setVisible(false);
        jPanel4.setVisible(false);
        jLabel46.setVisible(false);
        jLabel45.setVisible(false);
        jLabel47.setVisible(false);
        jLabel48.setVisible(false);
        jLabel49.setVisible(false);
        jLabel50.setVisible(true);
        jLabel51.setVisible(true);
        met.iconlbl(jLabel50,"src\\Imagenes\\Supersol.jpg");
        met.iconlbl(jLabel51, "src\\Imagenes\\Supersol_d.jpg");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLfondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel50.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel50.setMaximumSize(new java.awt.Dimension(430, 410));
        jLabel50.setPreferredSize(new java.awt.Dimension(277, 410));
        getContentPane().add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, 260, 410));

        jLabel51.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel51.setMaximumSize(new java.awt.Dimension(430, 410));
        jLabel51.setPreferredSize(new java.awt.Dimension(277, 410));
        getContentPane().add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 40, -1, -1));

        jLabel49.setBackground(new java.awt.Color(0, 0, 0));
        jLabel49.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 24)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 255, 255));
        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel49.setOpaque(true);
        getContentPane().add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 40, 240, 60));

        jLabel48.setBackground(new java.awt.Color(255, 51, 51));
        jLabel48.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 14)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel48.setText("Salir");
        jLabel48.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel48.setMaximumSize(new java.awt.Dimension(122, 19));
        jLabel48.setOpaque(true);
        jLabel48.setPreferredSize(new java.awt.Dimension(122, 19));
        jLabel48.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel48MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 380, 140, 50));

        jLabel47.setBackground(new java.awt.Color(255, 0, 51));
        jLabel47.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 14)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel47.setText("Volver a Jugar");
        jLabel47.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel47.setOpaque(true);
        jLabel47.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel47MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 380, 140, 50));

        jLabel45.setBackground(new java.awt.Color(0, 0, 0));
        jLabel45.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 18)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel45.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel45.setOpaque(true);
        getContentPane().add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 140, 410, 130));

        jLabel46.setBackground(new java.awt.Color(255, 51, 51));
        jLabel46.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 18)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel46.setText("Pelear");
        jLabel46.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel46.setOpaque(true);
        jLabel46.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel46MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 330, 100, 40));

        jPanel2.setOpaque(false);

        jLabel13.setBackground(new java.awt.Color(0, 0, 0));
        jLabel13.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setAlignmentX(40.0F);
        jLabel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel13.setMaximumSize(new java.awt.Dimension(300, 400));
        jLabel13.setOpaque(true);
        jLabel13.setPreferredSize(new java.awt.Dimension(180, 180));

        jLabel14.setBackground(new java.awt.Color(0, 0, 0));
        jLabel14.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Ataque:");
        jLabel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel14.setOpaque(true);

        jLabel15.setBackground(new java.awt.Color(0, 0, 0));
        jLabel15.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Defensa:");
        jLabel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel15.setOpaque(true);

        jLabel16.setBackground(new java.awt.Color(0, 0, 0));
        jLabel16.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Velocidad:");
        jLabel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel16.setOpaque(true);

        jLabel17.setBackground(new java.awt.Color(0, 0, 0));
        jLabel17.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Agilidad:");
        jLabel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel17.setOpaque(true);

        jLabel18.setBackground(new java.awt.Color(0, 0, 0));
        jLabel18.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Resistencia");
        jLabel18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel18.setOpaque(true);

        jLabel19.setBackground(new java.awt.Color(0, 0, 0));
        jLabel19.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Inteligencia:");
        jLabel19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel19.setOpaque(true);

        jLabel20.setBackground(new java.awt.Color(0, 0, 0));
        jLabel20.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Suerte: ");
        jLabel20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel20.setOpaque(true);

        jLabel21.setBackground(new java.awt.Color(0, 0, 0));
        jLabel21.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("jLabel21");
        jLabel21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel21.setOpaque(true);

        jLabel22.setBackground(new java.awt.Color(0, 0, 0));
        jLabel22.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("jLabel21");
        jLabel22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel22.setOpaque(true);

        jLabel23.setBackground(new java.awt.Color(0, 0, 0));
        jLabel23.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("jLabel21");
        jLabel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel23.setOpaque(true);

        jLabel24.setBackground(new java.awt.Color(0, 0, 0));
        jLabel24.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("jLabel21");
        jLabel24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel24.setOpaque(true);

        jLabel25.setBackground(new java.awt.Color(0, 0, 0));
        jLabel25.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("jLabel21");
        jLabel25.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel25.setOpaque(true);

        jLabel26.setBackground(new java.awt.Color(0, 0, 0));
        jLabel26.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("jLabel21");
        jLabel26.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel26.setOpaque(true);

        jLabel27.setBackground(new java.awt.Color(0, 0, 0));
        jLabel27.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("jLabel21");
        jLabel27.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel27.setOpaque(true);

        jLabel28.setBackground(new java.awt.Color(0, 0, 0));
        jLabel28.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("jLabel28");
        jLabel28.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel28.setOpaque(true);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(74, 74, 74)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel27)
                                    .addComponent(jLabel26)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel24)
                                    .addComponent(jLabel23)
                                    .addComponent(jLabel22)
                                    .addComponent(jLabel21)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(jLabel28)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(jLabel21))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel22))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel23))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(jLabel24))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel25))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jLabel26))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(jLabel27))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, 260, 410));

        jPanel4.setOpaque(false);

        jLabel29.setBackground(new java.awt.Color(0, 0, 0));
        jLabel29.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setAlignmentX(40.0F);
        jLabel29.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel29.setMaximumSize(new java.awt.Dimension(300, 400));
        jLabel29.setOpaque(true);
        jLabel29.setPreferredSize(new java.awt.Dimension(180, 180));

        jLabel30.setBackground(new java.awt.Color(0, 0, 0));
        jLabel30.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Ataque:");
        jLabel30.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel30.setOpaque(true);

        jLabel31.setBackground(new java.awt.Color(0, 0, 0));
        jLabel31.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("Defensa:");
        jLabel31.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel31.setOpaque(true);

        jLabel32.setBackground(new java.awt.Color(0, 0, 0));
        jLabel32.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("Velocidad:");
        jLabel32.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel32.setOpaque(true);

        jLabel33.setBackground(new java.awt.Color(0, 0, 0));
        jLabel33.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("Agilidad:");
        jLabel33.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel33.setOpaque(true);

        jLabel34.setBackground(new java.awt.Color(0, 0, 0));
        jLabel34.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Resistencia");
        jLabel34.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel34.setOpaque(true);

        jLabel35.setBackground(new java.awt.Color(0, 0, 0));
        jLabel35.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Inteligencia:");
        jLabel35.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel35.setOpaque(true);

        jLabel36.setBackground(new java.awt.Color(0, 0, 0));
        jLabel36.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Suerte: ");
        jLabel36.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel36.setOpaque(true);

        jLabel37.setBackground(new java.awt.Color(0, 0, 0));
        jLabel37.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("jLabel21");
        jLabel37.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel37.setOpaque(true);

        jLabel38.setBackground(new java.awt.Color(0, 0, 0));
        jLabel38.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("jLabel21");
        jLabel38.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel38.setOpaque(true);

        jLabel39.setBackground(new java.awt.Color(0, 0, 0));
        jLabel39.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("jLabel21");
        jLabel39.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel39.setOpaque(true);

        jLabel40.setBackground(new java.awt.Color(0, 0, 0));
        jLabel40.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("jLabel21");
        jLabel40.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel40.setOpaque(true);

        jLabel41.setBackground(new java.awt.Color(0, 0, 0));
        jLabel41.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("jLabel21");
        jLabel41.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel41.setOpaque(true);

        jLabel42.setBackground(new java.awt.Color(0, 0, 0));
        jLabel42.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("jLabel21");
        jLabel42.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel42.setOpaque(true);

        jLabel43.setBackground(new java.awt.Color(0, 0, 0));
        jLabel43.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("jLabel21");
        jLabel43.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel43.setOpaque(true);

        jLabel44.setBackground(new java.awt.Color(0, 0, 0));
        jLabel44.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 12)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("jLabel28");
        jLabel44.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel44.setOpaque(true);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel36, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel35, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel34, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel33, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel32, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel31, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(74, 74, 74)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel43)
                                    .addComponent(jLabel42)
                                    .addComponent(jLabel41)
                                    .addComponent(jLabel40)
                                    .addComponent(jLabel39)
                                    .addComponent(jLabel38)
                                    .addComponent(jLabel37)))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(jLabel44)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel44)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(jLabel37))
                .addGap(12, 12, 12)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(jLabel38))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(jLabel39))
                .addGap(12, 12, 12)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel33)
                    .addComponent(jLabel40))
                .addGap(12, 12, 12)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(jLabel41))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(jLabel42))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel36)
                    .addComponent(jLabel43))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 40, 260, 410));

        jScrollPane1.setPreferredSize(new java.awt.Dimension(118, 118));

        jPanel1.setMaximumSize(new java.awt.Dimension(1300, 118));
        jPanel1.setName(""); // NOI18N
        jPanel1.setOpaque(false);
        jPanel1.setPreferredSize(new java.awt.Dimension(1290, 116));

        jLabel1.setText("jLabel1");
        jLabel1.setMaximumSize(new java.awt.Dimension(200, 200));
        jLabel1.setPreferredSize(new java.awt.Dimension(100, 157));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel2.setText("jLabel2");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setText("jLabel3");
        jLabel3.setMaximumSize(new java.awt.Dimension(200, 200));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel4.setText("jLabel4");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel5.setText("jLabel5");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel6.setText("jLabel6");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel7.setText("jLabel7");
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel8.setText("jLabel8");
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });

        jLabel9.setText("jLabel9");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        jLabel10.setText("jLabel10");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        jLabel11.setText("jLabel11");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });

        jLabel12.setText("jLabel12");
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 480, 850, 170));

        jLfondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo.jpg"))); // NOI18N
        getContentPane().add(jLfondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
         met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(1)));
       jLabel21.setText(String.valueOf(Card.playerCards.get(1).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(1).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(1).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(1).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(1).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(1).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(1).sur));
       jLabel28.setText(Card.playerCards.get(1).tipo);
       jPanel2.setVisible(true);
       met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(1)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(1).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(1).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(1).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(1).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(1).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(1).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(1).sur));
       jLabel44.setText(Card.cpuCards.get(1).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=1;
       op_1.cartus=1;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
         met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(3)));
        jLabel21.setText(String.valueOf(Card.playerCards.get(3).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(3).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(3).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(3).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(3).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(3).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(3).sur));
       jLabel28.setText(Card.playerCards.get(3).tipo);
       jPanel2.setVisible(true);
       met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(3)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(3).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(3).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(3).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(3).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(3).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(3).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(3).sur));
       jLabel44.setText(Card.cpuCards.get(3).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=3;
       op_1.cartus=3;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
         met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(2)));
       jLabel21.setText(String.valueOf(Card.playerCards.get(2).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(2).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(2).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(2).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(2).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(2).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(2).sur));
       jLabel28.setText(Card.playerCards.get(2).tipo);
       jPanel2.setVisible(true);met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(2)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(2).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(2).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(2).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(2).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(2).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(2).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(2).sur));
       jLabel44.setText(Card.cpuCards.get(2).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=2;
       op_1.cartus=2;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(4)));
        jLabel21.setText(String.valueOf(Card.playerCards.get(4).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(4).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(4).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(4).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(4).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(4).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(4).sur));
       jLabel28.setText(Card.playerCards.get(4).tipo);
       jPanel2.setVisible(true);
       met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(4)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(4).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(4).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(4).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(4).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(4).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(4).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(4).sur));
       jLabel44.setText(Card.cpuCards.get(4).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=4;
       op_1.cartus=4;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(5)));
        jLabel21.setText(String.valueOf(Card.playerCards.get(5).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(5).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(5).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(5).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(5).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(5).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(5).sur));
       jLabel28.setText(Card.playerCards.get(5).tipo);
       jPanel2.setVisible(true);
       met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(5)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(5).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(5).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(5).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(5).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(5).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(5).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(5).sur));
       jLabel44.setText(Card.cpuCards.get(5).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=5;
       op_1.cartus=5;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(6)));
        jLabel21.setText(String.valueOf(Card.playerCards.get(6).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(6).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(6).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(6).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(6).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(6).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(6).sur));
       jLabel28.setText(Card.playerCards.get(6).tipo);
       jPanel2.setVisible(true);met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(6)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(6).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(6).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(6).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(6).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(6).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(6).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(6).sur));
       jLabel44.setText(Card.cpuCards.get(6).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=6;
       op_1.cartus=6;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel6MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(7)));
        jLabel21.setText(String.valueOf(Card.playerCards.get(7).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(7).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(7).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(7).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(7).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(7).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(7).sur));
       jLabel28.setText(Card.playerCards.get(7).tipo);
       jPanel2.setVisible(true);met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(7)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(7).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(7).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(7).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(7).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(7).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(7).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(7).sur));
       jLabel44.setText(Card.cpuCards.get(7).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=7;
       op_1.cartus=7;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(8)));
        jLabel21.setText(String.valueOf(Card.playerCards.get(8).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(8).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(8).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(8).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(8).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(8).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(8).sur));
       jLabel28.setText(Card.playerCards.get(8).tipo);
       jPanel2.setVisible(true);
       met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(8)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(8).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(8).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(8).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(8).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(8).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(8).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(8).sur));
       jLabel44.setText(Card.cpuCards.get(8).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=8;
       op_1.cartus=8;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(9)));
        jLabel21.setText(String.valueOf(Card.playerCards.get(9).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(9).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(9).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(9).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(9).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(9).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(9).sur));
       jLabel28.setText(Card.playerCards.get(9).tipo);
       jPanel2.setVisible(true);met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(9)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(9).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(9).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(9).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(9).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(9).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(9).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(9).sur));
       jLabel44.setText(Card.cpuCards.get(9).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=9;
       op_1.cartus=9;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(10)));
        jLabel21.setText(String.valueOf(Card.playerCards.get(10).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(10).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(10).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(10).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(10).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(10).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(10).sur));
       jLabel28.setText(Card.playerCards.get(10).tipo);
       jPanel2.setVisible(true);
       met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(10)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(10).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(10).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(10).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(10).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(10).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(10).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(10).sur));
       jLabel44.setText(Card.cpuCards.get(10).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=10;
       op_1.cartus=10;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel10MouseClicked

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(11)));
        jLabel21.setText(String.valueOf(Card.playerCards.get(11).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(11).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(11).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(11).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(11).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(11).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(11).sur));
       jLabel28.setText(Card.playerCards.get(11).tipo);
       jPanel2.setVisible(true);
       met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(11)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(11).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(11).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(11).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(11).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(11).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(11).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(11).sur));
       jLabel44.setText(Card.cpuCards.get(11).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=11;
       op_1.cartus=11;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        met.iconlbl(jLabel13, met.mostCj(Card.playerCards.get(12)));
        jLabel21.setText(String.valueOf(Card.playerCards.get(12).atk));
       jLabel22.setText(String.valueOf(Card.playerCards.get(12).def));
       jLabel23.setText(String.valueOf(Card.playerCards.get(12).vel));
       jLabel24.setText(String.valueOf(Card.playerCards.get(12).agl));
       jLabel25.setText(String.valueOf(Card.playerCards.get(12).res));
       jLabel26.setText(String.valueOf(Card.playerCards.get(12).intl));
       jLabel27.setText(String.valueOf(Card.playerCards.get(12).sur));
       jLabel28.setText(Card.playerCards.get(12).tipo);
       jPanel2.setVisible(true);met.iconlbl(jLabel29,met.mostCd(Card.cpuCards.get(12)));
       jLabel37.setText(String.valueOf(Card.cpuCards.get(12).atk));
       jLabel38.setText(String.valueOf(Card.cpuCards.get(12).def));
       jLabel39.setText(String.valueOf(Card.cpuCards.get(12).vel));
       jLabel40.setText(String.valueOf(Card.cpuCards.get(12).agl));
       jLabel41.setText(String.valueOf(Card.cpuCards.get(12).res));
       jLabel42.setText(String.valueOf(Card.cpuCards.get(12).intl));
       jLabel43.setText(String.valueOf(Card.cpuCards.get(12).sur));
       jLabel44.setText(Card.cpuCards.get(1).tipo);
       jLabel46.setVisible(true);
       ju_1.cartus=12;
       op_1.cartus=12;
       jLabel50.setVisible(false);
        jLabel51.setVisible(false);
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel46MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel46MouseClicked
        gg.Sum(ju_1.cartus,Card.playerCards,ju_1);
        gg.Sum(op_1.cartus,Card.cpuCards,op_1);
        if (ju_1.suerte != 0 || op_1.suerte != 0) {
            if (ju_1.suerte == 100) {
                jLabel49.setText("GANASTE");
                jLabel45.setText("<html>Con que has sacado 100 en suerte... que suerte... o que tramposo eres... Rata! Has ganado la partida, pero perdiste la dignidad.... si alguna vez la tuviste.<html>");
            } else if (ju_1.suerte == 1) {
                jLabel49.setText("PERDISTE");
               jLabel45.setText("<html>Que miserable! 1 en suerte? Patético. Ni tu madre te quiere y desde ahora serás conocido cómo Sir Pichula Triste, la decepción del reino.<html>");
            } else if (op_1.suerte == 100) {
               jLabel49.setText("PERDISTE");
               jLabel45.setText("<html>La suerte nunca estuvo de tu lado. Dios, siendo Dios, ha sacado 100 en suerte. No tuviste oportunidad y ahora estás condenado a la verguenza generacional eterna.<html>");
            } else if (op_1.suerte == 1) {
                jLabel49.setText("GANASTE");
               jLabel45.setText("<html>Quien lo diría? Dios ha tenido 1 en suerte... Así que supongo que has ganado? Como siempre, sin hacer una reverenda plasta de Wuok salvaje.<html>");
            }
        } else {
            if (ju_1.suat > op_1.suat) {
               jLabel49.setText("GANASTE");
               jLabel45.setText("<html>El hijo de perra lo hizo... Y ahora tengo que pagar la apuesta que perdí. Le has ganado a un Dios. Felicitaciones.<html>");
            } else if (ju_1.suat == op_1.suat) {
                jLabel49.setText("EMPATE");
               jLabel45.setText("<html>La verdad esto es sorprendente. Sabes cual es la posibilidad de un empate? Es casi nula! Pero bueno... no nos basta contigo, ahora tenemos dos perdedores.<html>");
            } else if (ju_1.suat < op_1.suat) {
                jLabel49.setText("PERDISTE");
               jLabel45.setText("<html>No esperabamos nada de ti, y aún así nos decepcionaste. Te espera un futuro oscuro. Dios a ganado!<html>");
            }
        }
        jPanel4.setVisible(true);
        jLabel45.setVisible(true);
        jLabel46.setVisible(false);
        jScrollPane1.setVisible(false);
        jLabel47.setVisible(true);
        jLabel48.setVisible(true);
        jLabel49.setVisible(true);
    }//GEN-LAST:event_jLabel46MouseClicked

    private void jLabel47MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel47MouseClicked
        Bien b=new Bien();
        b.setVisible(true);
        this.dispose();
        gg.resetGen();
    }//GEN-LAST:event_jLabel47MouseClicked

    private void jLabel48MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel48MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel48MouseClicked
    public void tipSe(){
        tipSkills(jLabel1,Card.playerCards.get(1));
        tipSkills(jLabel2,Card.playerCards.get(2));
        tipSkills(jLabel3,Card.playerCards.get(3));
        tipSkills(jLabel4,Card.playerCards.get(4));
        tipSkills(jLabel5,Card.playerCards.get(5));
        tipSkills(jLabel6,Card.playerCards.get(6));
        tipSkills(jLabel7,Card.playerCards.get(7));
        tipSkills(jLabel8,Card.playerCards.get(8));
        tipSkills(jLabel9,Card.playerCards.get(9));
        tipSkills(jLabel10,Card.playerCards.get(10));
        tipSkills(jLabel11,Card.playerCards.get(11));
        tipSkills(jLabel12,Card.playerCards.get(12));        
    }
    public void tipSkills(JLabel l,Card c){
        l.setToolTipText("<html>"+c.tipo
                + "<p> ATK: "+c.atk
                + "<p> DEF: "+c.def
                + "<p> VEL: "+c.vel
                + "<p> AGL: "+c.agl
                + "<p> RES: "+c.res
                + "<p> INT: "+c.intl
                + "<p> SUR: "+c.sur);
    }
    private void loadLabels(){
        met.Gam();
        met.iconlbl(jLabel1, met.mostCj(Card.playerCards.get(1)));
        met.iconlbl(jLabel2, met.mostCj(Card.playerCards.get(2)));
        met.iconlbl(jLabel3, met.mostCj(Card.playerCards.get(3)));
        met.iconlbl(jLabel4, met.mostCj(Card.playerCards.get(4)));
        met.iconlbl(jLabel5, met.mostCj(Card.playerCards.get(5)));
        met.iconlbl(jLabel6, met.mostCj(Card.playerCards.get(6)));
        met.iconlbl(jLabel7, met.mostCj(Card.playerCards.get(7)));
        met.iconlbl(jLabel8, met.mostCj(Card.playerCards.get(8)));
        met.iconlbl(jLabel9, met.mostCj(Card.playerCards.get(9)));
        met.iconlbl(jLabel10, met.mostCj(Card.playerCards.get(10)));
        met.iconlbl(jLabel11, met.mostCj(Card.playerCards.get(11)));
        met.iconlbl(jLabel12, met.mostCj(Card.playerCards.get(12)));
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DeadEnd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DeadEnd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DeadEnd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DeadEnd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeadEnd().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLfondo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}