package MeJu;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
public class Game {
    Random rd = new Random();
    Scanner sc = new Scanner(System.in);
    public static Game ju_1 = new Game();
    public static Game op_1 = new Game();
    public int cartus;
    public int SumAt=0;
    public int suat=0;
    public int SumDf=0;
    public int Sumpower=0;
    public int RondaG=0;
    public int suerte=0;
    public static int turnoAoD;
    public void Sum(int n, ArrayList<Card> l,Game ob) {
        ob.Sumpower += l.get(n).sumar;
        ob.SumAt += l.get(n).atk + l.get(n).vel + l.get(n).agl;
        ob.SumDf += l.get(n).def + l.get(n).res + l.get(n).intl;
        ob.suat += l.get(n).atk;
        if (l.get(n).sur == 100 || l.get(n).sur == 1) {
            ob.suerte = l.get(n).sur;
        } else ob.suerte = 0;
    }
    public void defturn() {
        turnoAoD = rd.nextInt(2);
    }
    public void reSum() {
        ju_1.Sumpower = 0;
        ju_1.suat = 0;
        ju_1.SumAt = 0;
        ju_1.SumDf = 0;
        ju_1.suerte = 0;
        op_1.Sumpower = 0;
        op_1.suat = 0;
        op_1.SumAt = 0;
        op_1.SumDf = 0;
        op_1.suerte = 0;
    }
    public void resetGen() {
        reSum();
        ju_1.RondaG = 0;
        op_1.RondaG = 0;
        Card.ResetCard();
    }
}