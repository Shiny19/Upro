import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class interfaz {
    public static void main(String[] args) {
        JFrame frame = new JFrame("interfaz");
        frame.setContentPane(new interfaz().root);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
    private JPanel root;
    private JPanel superior;
    private JPanel botones;
    private JButton btnreset;
    private JButton a7Button;
    private JButton a4Button;
    private JButton a1Button;
    private JButton btnpunto;
    private JButton a8Button;
    private JButton a9Button;
    private JButton btndiv;
    private JButton a5Button;
    private JButton a6Button;
    private JButton btnmulti;
    private JButton a2Button;
    private JButton a3Button;
    private JButton btnresta;
    private JButton a0Button;
    private JButton btnigual;
    private JButton btnsuma;
    private JLabel lbldisplay;
    private JButton btnpot;
    private JButton btnraiz;
    private JButton btnfact;
    private JButton btnpot3;

    public interfaz() {
        btnreset.addActionListener(e -> lbldisplay.setText(""));
        ActionListener listener = e -> {
            String texto = lbldisplay.getText() + ((JButton) e.getSource()).getText();
            lbldisplay.setText(texto);
        };
        a7Button.addActionListener(listener);
        a4Button.addActionListener(listener);
        a1Button.addActionListener(listener);
        btnpunto.addActionListener(listener);
        a8Button.addActionListener(listener);
        a9Button.addActionListener(listener);
        a5Button.addActionListener(listener);
        a6Button.addActionListener(listener);
        a2Button.addActionListener(listener);
        a3Button.addActionListener(listener);
        a0Button.addActionListener(listener);
        ActionListener listener1 = e -> {
            String resultado = calcular(lbldisplay.getText());
            lbldisplay.setText(resultado);
            if (e.getSource() != btnigual) {
                String texto = lbldisplay.getText() + ((JButton) e.getSource()).getText();
                lbldisplay.setText(texto);
            }
        };
        btndiv.addActionListener(listener1);
        btnmulti.addActionListener(listener1);
        btnresta.addActionListener(listener1);
        btnigual.addActionListener(listener1);
        btnsuma.addActionListener(listener1);
        btnpot.addActionListener(listener1);
        btnraiz.addActionListener(listener1);
        //btnfact.addActionListener(listener1);
        {
        }
        btnfact.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String resultado = fact(lbldisplay.getText());
                lbldisplay.setText(resultado);
                String texto = lbldisplay.getText() + ((JButton) e.getSource()).getText();
                lbldisplay.setText(texto);
            }
        });
    }

    public String calcular(String operation) {
        String resultado;
        String[] ops = operation.split("[+ p pp / r X  _]");
        if (ops.length == 1) {
            resultado = ops[0];
        } else {
            double v1 = Double.parseDouble(ops[0]);
            double v2 = Double.parseDouble(ops[1]);
            double r = 0;
            if (operation.contains("+")) r = v1 + v2;
            else if (operation.contains("_")) r = v1 - v2;
            else if (operation.contains("X")) r = v1 * v2;
            else if (operation.contains("p2")) r = Math.pow(v1, 2);
            else if (operation.contains("p3")) r = Math.pow(v1, 3);
            else if (operation.contains("r2")) r = Math.sqrt(v1);
            else if (operation.contains("fc")) {
                double er = 1;
                v2 = 1;
                for (int i = (int) v1; i > 0; i--) {
                    r = er * i;
                }
                r *= v2;
            } else {
                r = v1 / v2;
            }
            resultado = String.valueOf(r);
        }
        return resultado;
    }
    public String fact(String op) {
        String res = "";
        String[] opp = op.split("[fc]");
        double v1 = Double.parseDouble(opp[0]);
        double r = 1;
        if (opp.length == 1) {
            double v=Double.parseDouble(opp[0]);
            for (int i = (int) v; i > 0; i--) {
                r = r * i;
            }
            res = String.valueOf(r);
        }
        System.out.println(opp[0]);
        return res;
    }
}