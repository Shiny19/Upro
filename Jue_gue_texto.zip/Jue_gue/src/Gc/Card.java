package Gc;
import java.util.ArrayList;
import java.util.Random;
public class Card {
    /*
     * definir atributos generales de las cartas
     * atk=ataque, def=defensa, vel=velocidad, agl=agilidad, sur=suerte,
     * res=resistencia, intl=inteligencia.
     */
    static ArrayList<Card> cpuCards = new ArrayList<>();
    static ArrayList<Card> playerCards = new ArrayList<>();
    public int atk, def, vel, agl, sur, res, intl, sumar;
    static Random rd = new Random();
    String tipo = "valor"; // indica tipo de carta.
    public boolean activa = false; // indica estado de la carta.
    // valor a la habilidades de las cartas y dar el tipo.
    public void GenCards() {
        atk = rd.nextInt(100) + 1;
        def = rd.nextInt(100) + 1;
        vel = rd.nextInt(100) + 1;
        agl = rd.nextInt(100) + 1;
        sur = rd.nextInt(100) + 1;
        res = rd.nextInt(100) + 1;
        intl = rd.nextInt(100) + 1;
        activa = false;
        sumar = atk + def + vel + agl + res + intl;
        if (sumar / 6 > 90) {
            tipo = "Rey";
        } else if (sumar / 6 > 80) {
            tipo = "Mago";
        } else if (sumar / 6 > 65) {
            tipo = "Caballero";
        } else if (sumar / 6 > 45) {
            tipo = "Arquero";
        } else if (sumar / 6 > 30) {
            tipo = "Soldado";
        } else
            tipo = "Campesino";
    }
    //genera una lista de cartas para el jugador.
    public static void genCard(ArrayList<Card> p) {
        for (int i = 0; i < 13; i++) {
            Card card = new Card();
            card.GenCards();
            p.add(card);
        }
    }
    //metodo para mostrar las cartas.
    public void mostCard(int n, ArrayList<Card> l) {
        if (!l.get(n).activa) {
            System.out.println(n + ". " + tipo + " Ataque: " + atk + " Defensa: " + def + " Velocidad: " + vel + " Agilidad: " + agl + " Suerte: " + sur + " Resistencia: " + res + " Inteligencia: " + intl + '\n');
        }
    }
    //para mostrar las cartas del jugador.
    public static void mostCardj(int n, ArrayList<Card> l) {
        if (n == -1) {
            for (int i = 1; i < l.size(); i++) {
                l.get(i).mostCard(i, l);
            }
        } else {
            l.get(n).mostCard(n, l);
        }
    }
    public static void ResetCard() {
        playerCards.clear();
        cpuCards.clear();
    }
}