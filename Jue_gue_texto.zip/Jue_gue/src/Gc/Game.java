package Gc;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
public class Game {
    Random rd = new Random();
    Scanner sc = new Scanner(System.in);
    public static Game ju_1 = new Game();
    public static Game op_1 = new Game();
    public int cartus;
    public int SumAt=0;
    public int suat=0;
    public int SumDf=0;
    public int Sumpower=0;
    public int RondaG;
    public int suerte=0;
    public int ntu;
    public static int turnoAoD;
    //metodo de agrego de habilidades.
    public void inron(int n, int op) {
        switch (op) {
            case 1 -> {
                System.out.println("Aquí están tus cartas: ");
                Card.genCard(Card.playerCards);
                Card.mostCardj(-1, Card.playerCards);
                Card.genCard(Card.cpuCards);
                System.out.println("Elige 3 cartas del 1 al 12.");
                while (ntu < n) Elcar(ju_1.cartus = sc.nextInt());
                Power();
                reSum();
                Card.ResetCard();
            }
            case 2 -> {
                System.out.println("Aquí están tus cartas: ");
                if (n == 1) {
                    Card.genCard(Card.playerCards);
                    Card.genCard(Card.cpuCards);
                }
                Card.mostCardj(-1, Card.playerCards);
                defturn();
                System.out.println("Elige 1 de las cartas del 1 al 12.");
                while (ntu < n) Elcar(ju_1.cartus = sc.nextInt());
                Guerra(turnoAoD);
                //reSum();
            }
            case 3 -> {
                System.out.println("Aquí están tus cartas: ");
                Card.genCard(Card.playerCards);
                Card.genCard(Card.cpuCards);
                Card.mostCardj(-1, Card.playerCards);
                System.out.println("Elige 1 de las cartas del 1 al 12.");
                while (ntu < n) Elcar(ju_1.cartus = sc.nextInt());
                Final();
                reSum();
                Card.ResetCard();
            }
            default -> {
            }
        }
    }
    public void Sum(int n, ArrayList<Card> l,Game ob) {
        ob.Sumpower += l.get(n).sumar;
        ob.SumAt += l.get(n).atk + l.get(n).vel + l.get(n).res;
        ob.SumDf += l.get(n).def + l.get(n).agl + l.get(n).intl;
        ob.suat += l.get(n).atk;
        if (l.get(n).sur == 100 || l.get(n).sur == 1) {
            ob.suerte = l.get(n).sur;
        } else ob.suerte = 0;
    }
    public void resop() {
        int m=Integer.MIN_VALUE;
        for (int i=1;i<Card.cpuCards.size();i++) {
            if (!Card.cpuCards.get(i).activa){
                if (Card.cpuCards.get(i).sumar>m){
                    m=Card.cpuCards.get(i).sumar;
                    op_1.cartus=i;
                }
            }
        }
        vercop(op_1.cartus);
        Sum(op_1.cartus, Card.cpuCards,op_1);
    }
    public void vercop(int n) {
        if (Card.cpuCards.get(n).activa) {
            resop();
        } else {
            System.out.println("carta de dios:\n");
            Card.mostCardj(n, Card.cpuCards);
            Card.cpuCards.get(n).activa = true;
        }
    }
    public void Elcar(int n) {
        if (Card.playerCards.get(n).activa) {
            System.out.println("Vaya inutil.... esta carta ya ha sido elegida...Espero no puedas reproducirte." + "\nElige otra carta, insecto.");
            Elcar(ju_1.cartus = sc.nextInt());
        } else {
            System.out.println("Carta de invocador:\n");
            Card.mostCardj(n, Card.playerCards);
            Sum(n, Card.playerCards,ju_1);
            Card.playerCards.get(n).activa = true;
            resop();
            ntu++;
        }
    }
    public void defturn() {
        turnoAoD = rd.nextInt(2);
        if (turnoAoD == 0) System.out.println("Eres el atacante. A por ellos! Ataca!");
        else System.out.println("Eres el defensor. Estas siendo atacado. Defiendete! ");
    }
    public void Power() {
        System.out.println("Poder total adquirido por el invocador: " + ju_1.Sumpower);
        System.out.println("Poder total adquidrido por Dios: " + op_1.Sumpower);
        if (ju_1.Sumpower > op_1.Sumpower) {
            System.out.println("Has vencido. La ronda es tuya:");
            ju_1.RondaG++;
        } else if (ju_1.Sumpower == op_1.Sumpower) {
            System.out.println("Choque de iguales. La ronda está empatada.");
        } else if (ju_1.Sumpower < op_1.Sumpower) {
            System.out.println("Te la tragas. La derrota pues. Perdiste la ronda.");
            op_1.RondaG++;
        }
        reSum();
        Card.ResetCard();
    }
    public void Guerra(int turnoAoD) {
        //si el jugador ataca
        if (turnoAoD == 0) {
            System.out.println("El ataque total del invocador es: " + ju_1.SumAt);
            System.out.println("La defensa total de Dios es: " + op_1.SumDf);
            if (ju_1.SumAt > op_1.SumDf) {
                System.out.println("Has vencido. La ronda es tuya: ");
                ju_1.RondaG++;
            } else if (ju_1.SumAt == op_1.SumDf) {
                System.out.println("Choque de iguales. La ronda está empatada.");
            } else if (ju_1.SumAt < op_1.SumDf) {
                System.out.println("Te la tragas. La derrota pues. Perdiste la ronda.");
                op_1.RondaG++;
            }
            op_1.SumDf=0;
            ju_1.SumAt=0;
        }
        //Si el jugador defiende.
        else {
            System.out.println("La defensa total del invocador es: " + ju_1.SumDf);
            System.out.println("El ataque total de Dios es: " + op_1.SumAt);
            if (ju_1.SumDf > op_1.SumAt) {
                System.out.println("Has vencido. La ronda es tuya: ");
                ju_1.RondaG++;
            } else if (ju_1.SumDf == op_1.SumAt) {
                System.out.println("Choque de iguales. La ronda está empatada.");
            } else if (ju_1.SumDf < op_1.SumAt) {
                System.out.println("Te la tragas. La derrota pues. Perdiste la ronda.");
                op_1.RondaG++;
            }
            op_1.SumAt=0;
            ju_1.SumDf=0;
        }
        reSum();
    }
    public static void Final() {
        System.out.println("El ataque total del invocador es: " + ju_1.suat);
        System.out.println("El ataque total de Dios es: " + op_1.suat);
        if (ju_1.suerte != 0 || op_1.suerte != 0) {
            if (ju_1.suerte == 100) {
                System.out.println("Con que has sacado 100 en suerte... que suerte... o que tramposo eres... Rata! Has ganado la partida, pero perdiste la dignidad.... si alguna vez la tuviste.");
                ju_1.RondaG++;
            } else if (ju_1.suerte == 1) {
                System.out.println("Que miserable! 1 en suerte? Patético. Ni tu madre te quiere y desde ahora serás conocido cómo Sir Pichula Triste, la decepción del reino.");
                op_1.RondaG++;
            } else if (op_1.suerte == 100) {
                System.out.println("La suerte nunca estuvo de tu lado. Dios, siendo Dios, ha sacado 100 en suerte. No tuviste oportunidad y ahora estás condenado a la verguenza generacional eterna.");
                op_1.RondaG++;
            } else if (op_1.suerte == 1) {
                System.out.println("Quien lo diría? Dios ha tenido 1 en suerte... Así que supongo que has ganado? Como siempre, sin hacer una reverenda plasta de Wuok salvaje.");
                ju_1.RondaG++;
            }
        } else {
            if (ju_1.suat > op_1.suat) {
                System.out.println("Has vencido. La ronda es tuya:");
                ju_1.RondaG++;
            } else if (ju_1.suat == op_1.suat) {
                System.out.println("Choque de iguales. La ronda está empatada.");
            } else if (ju_1.suat < op_1.suat) {
                System.out.println("Te la tragas. La derrota pues. Perdiste la ronda.");
                op_1.RondaG++;
            }
        }
    }
    public void vefWin() {
        if (ju_1.RondaG > op_1.RondaG)
            System.out.println("El hijo de perra lo hizo... Y ahora tengo que pagar la apuesta que perdí. Le has ganado a un Dios. Felicitaciones.");
        else if (ju_1.RondaG == op_1.RondaG)
            System.out.println("La verdad esto es sorprendente. Sabes cual es la posibilidad de un empate? Es casi nula! Pero bueno... no nos basta contigo, ahora tenemos dos perdedores.");
        else if (ju_1.RondaG < op_1.RondaG)
            System.out.println("No esperabamos nada de ti, y aún así nos decepcionaste. Te espera un futuro oscuro.");

    }
    public void reSum() {
        ju_1.Sumpower = 0;
        ju_1.suat = 0;
        ju_1.SumAt = 0;
        ju_1.SumDf = 0;
        ju_1.suerte = 0;
        op_1.Sumpower = 0;
        op_1.suat = 0;
        op_1.SumAt = 0;
        op_1.SumDf = 0;
        op_1.suerte = 0;
    }
    public void resetGen() {
        reSum();
        ju_1.RondaG = 0;
        op_1.RondaG = 0;
        Card.ResetCard();
    }
    public void Menu() {
        System.out.println("""
                Bienvenido al juego.
                Deseas tener poder?.
                1. SI
                2. NO""");
        int co = sc.nextInt();
        switch (co) {
            case 1 -> {
                System.out.println("""
                        Eige el modo de juego:
                        1. Poder Total: en este modo se te entregaran 12 cartas y tendras 4 turnos. Por turno puedes usar 3 cartas. Al final de cada turno te contestará la cpu y al finalizar cada turno se evaluarán todas las habilidades para determinar al ganador del turno.
                        2. Guerra: en este modo el poder total no es importante. Todo depende de la posicion en la que estes. Tendrás que buscar la mejor opción para poder derrotar a tu oponente.
                        3. Muerte Subita: solo una carta te dará la victoria... pero no siempre el ganador será el que tenga más ataque.""");
                int op = sc.nextInt();
                switch (op) {
                    case 1 -> {
                        System.out.println("En este modo se te entregan 12 cartas distintas cada turno, de las cuales puedes elegir 3 por turno. Se sumaran todas sus habilidades y serán comparadas al final de cada turno con las tres cartas de Dios.");
                        System.out.println("presiona 1 para empezar");
                        int res = sc.nextInt();
                        while (res == 1) {
                            int r = 1;
                            for (int i = 3; i <= 12; i += 3) {
                                System.out.println("ronda #" + r);
                                r++;
                                inron(i, op);
                                if (i < 12) {
                                    System.out.println("Presiona 1 para continuar.");
                                    sc.nextInt();
                                }
                            }
                            vefWin();
                            ntu = 0;
                            resetGen();
                            System.out.println("El destino ha sido decidido... Largo de mi presencia!.");
                            break;
                        }
                    }
                    case 2 -> {
                        System.out.println("En este modo se elegiraá al azar si tienes que atacar o defender. Si atacas, se sumarán el ataque, la velocidad y la resistencia de la carta. Si defiendes se sumarán la inteligencia, la agilidad y la defensa.");
                        System.out.println("presiona 1 para empezar");
                        int res = sc.nextInt();
                        if (res == 1) {
                            for (int i = 1; i < 13; i++) {
                                System.out.println(i + " Ronda.");
                                inron(i, op);
                                if (i < 12) {
                                    System.out.println("Presiona 1 para continuar.");
                                    sc.nextInt();
                                }
                            }
                            vefWin();
                            ntu = 0;
                            resetGen();
                            System.out.println("El destino ha sido decidido... Largo de mi presencia!.");
                        }
                    }
                    case 3 -> {
                        System.out.println("En este modo tendrás que elegir una sola carta de las 12 que se te entregan. Esta carta se comparará con la de Dios. Aquí solo comparas el ataque de la carta.");
                        System.out.println("Ronda a muerte. Raedy... set...go!");
                        System.out.println("presiona 1 para empezar");
                        int res = sc.nextInt();
                        if (res == 1) {
                            inron(1, op);
                            vefWin();
                            ntu = 0;
                            resetGen();
                            System.out.println("El destino ha sido decidido... Largo de mi presencia!.");
                        }
                    }
                    default -> System.out.println("Genial ganaste el trofeo ''EXPERTO EN LECTURA''... Decepcionante.");
                }
            }
            case 2 ->
                    System.out.println("Cobarde! No mereces el poder, has sido destinado a ser un simple campesino por la eternidad.");
            default -> System.out.println("Ingresaste un valor casi tan invalido como tu, que poco sorprendente.");
        }
        System.out.println("Fuera de aqui!");
    }
}